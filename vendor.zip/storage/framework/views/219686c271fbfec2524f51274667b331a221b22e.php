<div class="text-right text-nowrap">
    <a href="<?php echo e(route('admin.activity_logs.read', $activity_log->id)); ?>" class="btn btn-link text-secondary p-1" title="Read"><i class="fal fa-lg fa-eye"></i></a>
</div>