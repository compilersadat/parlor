<div class="text-right text-nowrap">
    <a href="<?php echo e(route('admin.users.read', $user->id)); ?>" class="btn btn-link text-secondary p-1" title="Read"><i class="fal fa-lg fa-eye"></i></a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Update Users')): ?>
        <a href="<?php echo e(route('admin.users.update', $user->id)); ?>" class="btn btn-link text-secondary p-1" title="Update"><i class="fal fa-lg fa-edit"></i></a>
        <a href="<?php echo e(route('admin.users.password', $user->id)); ?>" class="btn btn-link text-secondary p-1" title="Change Password"><i class="fal fa-lg fa-unlock-alt"></i></a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Users')): ?>
        <form method="POST" action="<?php echo e(route('admin.users.delete', $user->id)); ?>" class="d-inline-block" novalidate data-ajax-form>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" name="_submit" class="btn btn-link text-secondary p-1" title="Delete" value="reload_datatables" data-confirm>
                <i class="fal fa-lg fa-trash-alt"></i>
            </button>
        </form>
    <?php endif; ?>
</div>