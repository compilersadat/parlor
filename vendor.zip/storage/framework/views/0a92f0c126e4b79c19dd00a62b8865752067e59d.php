<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('child-content'); ?>

    <div class="col-xs-12">
        <div class="box">

            <div class="box-header">
                <div class="pull-right">
                    <a href="<?php echo e(route('services.create')); ?>" class=" btn bg-maroon "><i class="fa fa-plus"></i> Create New </a><br>

                </div>

                <h3 class="box-title">Attendants</h3>

            </div>
            <div class="box-body ">
                <table class="table table-bordered table-striped" id="att" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SR NO</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Actions</th>

                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>SR NO</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $i=1;?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><a href="<?php echo e(asset('../storage/app/service/'.$row->image)); ?>"><img src="<?php echo e(asset('../storage/app/service/'.$row->image)); ?>" width="80"></a></td>
                            <td><?php echo e($row->price); ?></td>
                            <td><?php echo e($row->description); ?></td>
                            <td><a href="<?php echo e(route('services.edit',$row->id)); ?>" class="label bg-blue"><i class="fa fa-edit"></i> Edit</a>
                                <a href="<?php echo e(route('services.delete',$row->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="label bg-red-active"><i class="fa fa-trash"></i> Delete</a>
                                <a href="<?php echo e(route('services.show',$row->id)); ?>"><span class="label bg-info"><i class="fa fa-eye"></i>&ensp;See Details</span></a>
                            </td>
                        </tr>
                        <?php $i++?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('lap::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>