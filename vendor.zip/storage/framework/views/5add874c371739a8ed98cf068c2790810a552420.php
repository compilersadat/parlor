<?php $__env->startSection('title', 'Activity Logs'); ?>
<?php $__env->startSection('child-content'); ?>
    <h2><?php echo $__env->yieldContent('title'); ?></h2>

    <div class="card">
        <div class="card-body">
            <?php echo $html->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $html->scripts(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('lap::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>