<?php $__env->startSection('body-class', 'bg-grey'); ?>
<?php $__env->startSection('parent-content'); ?>
    <div class="container h-100">
        <div class="row justify-content-center align-items-center h-100">
            <div class="col-md-4">
                <h2 class="text-center mb-3">
                    <a href="<?php echo e(route('admin')); ?>" class="text-dark text-decoration-none">
                        <i class="fal fa-cog text-primary"></i> <?php echo e(config('app.name')); ?>

                    </a>
                </h2>

                <div class="card mb-5">
                    <div class="card-body">
                        <?php echo $__env->yieldContent('child-content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lap::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>