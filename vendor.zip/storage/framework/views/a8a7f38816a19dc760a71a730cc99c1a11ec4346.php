<div style="margin-left: <?php echo e($doc->depth * .75); ?>rem"<?php echo $doc->type == 'Menu Heading' ? ' class="font-weight-bold"' : ''; ?>>
    <?php echo e($doc->title); ?>

</div>