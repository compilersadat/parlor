<?php $__env->startSection('title', 'Docs'); ?>
<?php $__env->startSection('child-content'); ?>
    <div class="row mb-3">
        <div class="col-md">
            <h2 class="mb-0"><?php echo $__env->yieldContent('title'); ?></h2>
        </div>
        <div class="col-md-auto mt-2 mt-md-0">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Docs')): ?>
                <a href="<?php echo e(route('admin.docs.create')); ?>" class="btn btn-primary">Create Doc</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <?php echo $html->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $html->scripts(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('lap::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>