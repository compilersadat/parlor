<li<?php echo request()->is('admin/dashboard') ? ' class="active"' : ''; ?>>
    <a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fal fa-fw fa-tachometer mr-3"></i>Dashboard</a>
</li>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Read Roles')): ?>
    <li<?php echo request()->is('admin/roles') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('admin.roles')); ?>"><i class="fal fa-fw fa-shield-alt mr-3"></i>Roles</a>
    </li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Read Users')): ?>
    <li<?php echo request()->is('admin/users') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('admin.users')); ?>"><i class="fal fa-fw fa-user mr-3"></i>Users</a>
    </li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Read Users')): ?>
    <li<?php echo request()->is('services') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('services.index')); ?>"><i class="fal fa-fw fa-shield-alt mr-3"></i>Services</a>
    </li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Read Activity Logs')): ?>
    <li<?php echo request()->is('admin/activity_logs') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('admin.activity_logs')); ?>"><i class="fal fa-fw fa-file-alt mr-3"></i>Activity Logs</a>
    </li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Read Docs')): ?>
    <li<?php echo request()->is('admin/docs') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('admin.docs')); ?>"><i class="fal fa-fw fa-book mr-3"></i>Docs</a>
    </li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Update Settings')): ?>
    <li<?php echo request()->is('admin/settings') ? ' class="active"' : ''; ?>>
        <a href="<?php echo e(route('admin.settings')); ?>"><i class="fal fa-fw fa-cog mr-3"></i>Settings</a>
    </li>
<?php endif; ?>
