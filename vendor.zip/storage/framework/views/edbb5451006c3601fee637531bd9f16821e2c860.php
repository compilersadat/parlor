<?php $__env->startSection('body-class', 'bg-grey'); ?>
<?php $__env->startSection('parent-content'); ?>
    <nav class="navbar navbar-expand navbar-dark bg-primary">
        <a class="sidebar-toggle mr-3" href="#"><i class="far fa-fw fa-bars"></i></a>
        <a class="navbar-brand" href="<?php echo e(route('admin')); ?>"><?php echo e(config('app.name')); ?></a>

        <div class="navbar-collapse collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="<?php echo e(route('docs')); ?>" class="nav-link" target="_blank">
                        <i class="fal fa-question-circle"></i> <span class="d-none d-md-inline">Docs</span>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" id="userDropdown" class="nav-link dropdown-toggle" data-toggle="dropdown">
                        <i class="fal fa-user-circle"></i> <span class="d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a href="<?php echo e(route('admin.profile')); ?>" class="dropdown-item<?php echo e(request()->is('admin/profile') ? ' active' : ''); ?>">Update Profile</a>
                        <a href="<?php echo e(route('admin.password.change')); ?>" class="dropdown-item<?php echo e(request()->is('admin/password/change') ? ' active' : ''); ?>">Change Password</a>
                        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="#" id="logout_link" class="dropdown-item">Logout</a>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="wrapper d-flex">
        <div class="sidebar sidebar-dark bg-dark">
            <ul class="list-unstyled list-admin mb-0">
                <?php echo $__env->make('lap::layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
        </div>

        <div class="content p-3 p-md-5">
            <?php echo $__env->yieldContent('child-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lap::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>