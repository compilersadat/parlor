<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('child-content'); ?>
    <?php if(config('lap.demo.enabled')): ?>
        <div class="alert bg-warning">
            <b>Currently in demo mode!</b><br>
            Some features are disabled.
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.login')); ?>" novalidate data-ajax-form>
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <input type="email" name="email" id="email" class="form-control" placeholder="Email Address" value="<?php echo e(config('lap.demo.enabled') ? config('lap.demo.user.email') : ''); ?>">
        </div>

        <div class="form-group">
            <input type="password" name="password" id="password" class="form-control" placeholder="Password" value="<?php echo e(config('lap.demo.enabled') ? config('lap.demo.user.password') : ''); ?>">
        </div>

        <div class="row mb-3">
            <div class="col">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="remember" id="remember" class="custom-control-input">
                    <label for="remember" class="custom-control-label">Remember Me</label>
                </div>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('admin.password.request')); ?>">Forgot Password?</a>
            </div>
        </div>

        <input type="hidden" name="auth_user_timezone" id="auth_user_timezone">

        <button type="submit" class="btn btn-block btn-primary">Login</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lap::layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>