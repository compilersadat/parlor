<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('child-content'); ?>
    <h2><?php echo $__env->yieldContent('title'); ?></h2>

    <div class="card">
        <div class="card-body">
            You are logged in!
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lap::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>